FCSV 2027 author kit (fictional venue: Fictional Conference on Synthetic Vision).
Submissions are anonymous. Synthetic test material. All people, institutions, venues and results are fictional.
